const actionTypes = {
    GET_FACEANNOTATION_SUCCESS: "GET_FACEANNOTATION_SUCCESS"
};

export default actionTypes;